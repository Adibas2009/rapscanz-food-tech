import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export type BodyDamage = {
  part: string;
  severity: "low" | "medium" | "high";
  reason: string;
  /** The specific chemical / nutrient / ingredient that triggered this impact. */
  trigger?: string;
};

export type BodyMapVariant = "damage" | "benefit";

const SEVERITY_COLOR: Record<BodyMapVariant, Record<string, string>> = {
  damage: {
    low: "#fbbf24",
    medium: "#fb923c",
    high: "#ef4444",
  },
  benefit: {
    low: "#86efac",
    medium: "#4ade80",
    high: "#22c55e",
  },
};

const BODY_STROKE: Record<BodyMapVariant, string> = {
  damage: "#7dd3fc",
  benefit: "#86efac",
};

const GLOW_SHADOW: Record<BodyMapVariant, string> = {
  damage: "drop-shadow(0 0 18px rgba(239,68,68,0.25))",
  benefit: "drop-shadow(0 0 18px rgba(34,197,94,0.3))",
};

/**
 * Anatomically-correct organ positions on a front-facing human silhouette
 * (viewer's POV — the subject's LEFT side appears on the viewer's RIGHT).
 * ViewBox: 260 x 600.
 *
 * Each organ has its own SVG path so we can highlight the exact organ when
 * it's affected (or benefited) by the scanned product.
 */
type OrganDef = {
  label: string;
  /** SVG path for the organ shape. */
  path: string;
  /** Anchor point for the callout label (inside the body). */
  anchor: { x: number; y: number };
  /** Where the label text sits (outside the body). */
  callout: { x: number; y: number };
};

const ORGANS: Record<string, OrganDef> = {
  brain: {
    label: "Brain",
    path: "M112 28 Q108 16 122 14 Q140 12 150 22 Q160 30 156 42 Q152 52 140 52 Q124 54 116 46 Q108 40 112 28 Z",
    anchor: { x: 134, y: 32 },
    callout: { x: 232, y: 30 },
  },
  eyes: {
    label: "Eyes",
    path: "M120 64 a4 2.5 0 1 0 8 0 a4 2.5 0 1 0 -8 0 M140 64 a4 2.5 0 1 0 8 0 a4 2.5 0 1 0 -8 0",
    anchor: { x: 134, y: 64 },
    callout: { x: 24, y: 60 },
  },
  teeth: {
    label: "Teeth / Mouth",
    path: "M122 84 L150 84 L150 90 L122 90 Z M126 84 L126 90 M132 84 L132 90 M138 84 L138 90 M144 84 L144 90",
    anchor: { x: 136, y: 87 },
    callout: { x: 232, y: 86 },
  },
  throat: {
    label: "Throat",
    path: "M128 100 L144 100 L142 124 L130 124 Z",
    anchor: { x: 136, y: 112 },
    callout: { x: 24, y: 112 },
  },
  // Heart: anatomically on the subject's LEFT → viewer's RIGHT of midline.
  heart: {
    label: "Heart",
    path: "M150 152 Q138 138 128 148 Q120 156 130 170 Q140 184 150 192 Q160 184 170 170 Q180 156 172 148 Q162 138 150 152 Z",
    anchor: { x: 150, y: 168 },
    callout: { x: 232, y: 160 },
  },
  lungs: {
    label: "Lungs",
    // Two lobes flanking the heart, larger on the right lobe (subject's right = viewer's left).
    path: "M110 146 Q88 154 86 196 Q86 220 102 224 Q120 224 122 200 L122 152 Q118 144 110 146 Z M158 152 L158 200 Q160 224 178 224 Q194 220 194 196 Q192 154 170 146 Q162 144 158 152 Z",
    anchor: { x: 104, y: 188 },
    callout: { x: 24, y: 188 },
  },
  // Liver: subject's RIGHT upper abdomen → viewer's LEFT.
  liver: {
    label: "Liver",
    path: "M98 230 Q92 244 102 258 Q128 270 152 262 Q160 258 158 248 Q156 238 148 232 Q126 226 110 226 Q102 226 98 230 Z",
    anchor: { x: 124, y: 246 },
    callout: { x: 24, y: 240 },
  },
  // Stomach: subject's LEFT upper abdomen → viewer's RIGHT.
  stomach: {
    label: "Stomach",
    path: "M152 244 Q166 244 174 256 Q180 272 168 282 Q156 288 148 278 Q140 268 144 256 Q148 246 152 244 Z",
    anchor: { x: 162, y: 266 },
    callout: { x: 232, y: 260 },
  },
  pancreas: {
    label: "Pancreas",
    path: "M108 274 Q140 268 174 280 Q170 286 138 284 Q116 284 108 280 Z",
    anchor: { x: 140, y: 278 },
    callout: { x: 232, y: 290 },
  },
  // Kidneys: two beans flanking the spine, behind organs.
  kidneys: {
    label: "Kidneys",
    path: "M104 296 Q94 300 96 320 Q100 336 114 332 Q120 326 118 312 Q116 298 104 296 Z M168 296 Q180 298 180 312 Q178 326 172 332 Q160 336 156 320 Q158 300 168 296 Z",
    anchor: { x: 136, y: 314 },
    callout: { x: 24, y: 312 },
  },
  intestines: {
    label: "Intestines",
    path: "M104 344 Q100 360 116 360 Q132 360 132 348 Q132 360 148 360 Q164 360 164 348 Q166 364 152 368 Q132 372 116 368 Q102 364 104 354 M100 372 Q100 392 124 394 Q150 394 168 388 Q176 384 174 372",
    anchor: { x: 134, y: 372 },
    callout: { x: 232, y: 372 },
  },
  skin: {
    label: "Skin",
    // Full-body subtle outline used as the "skin" highlight.
    path: "M134 110 Q92 116 88 156 L92 250 Q94 296 100 336 Q108 372 116 400 L152 400 Q160 372 168 336 Q174 296 176 250 L180 156 Q176 116 134 110 Z",
    anchor: { x: 134, y: 250 },
    callout: { x: 24, y: 430 },
  },
  bones: {
    label: "Bones",
    // Ribcage + pelvis lines, used as the "bones" highlight.
    path: "M104 130 Q134 124 164 130 L168 152 L100 152 Z M104 158 L164 158 M104 170 L164 170 M104 182 L164 182 M104 194 L164 194 M100 408 Q134 416 168 408 L172 426 Q150 436 118 436 Q100 432 100 420 Z",
    anchor: { x: 134, y: 200 },
    callout: { x: 232, y: 432 },
  },
};

function normalizePart(p: string): string {
  const k = p.toLowerCase().trim();
  if (k.includes("brain") || k.includes("neuro") || k.includes("cogniti") || k.includes("memory")) return "brain";
  if (k.includes("eye") || k.includes("vision") || k.includes("sight")) return "eyes";
  if (k.includes("teeth") || k.includes("dental") || k.includes("tooth") || k.includes("enamel") || k.includes("mouth")) return "teeth";
  if (k.includes("throat") || k.includes("esoph")) return "throat";
  if (k.includes("heart") || k.includes("cardio") || k.includes("arter")) return "heart";
  if (k.includes("lung") || k.includes("respir")) return "lungs";
  if (k.includes("liver") || k.includes("hepat")) return "liver";
  if (k.includes("stomach") || k.includes("gastr")) return "stomach";
  if (k.includes("pancre") || k.includes("insulin") || k.includes("diabet")) return "pancreas";
  if (k.includes("kidney") || k.includes("renal")) return "kidneys";
  if (k.includes("intest") || k.includes("gut") || k.includes("bowel") || k.includes("colon") || k.includes("microbi")) return "intestines";
  if (k.includes("skin") || k.includes("derm") || k.includes("collagen")) return "skin";
  if (k.includes("bone") || k.includes("joint") || k.includes("calcium") || k.includes("muscle")) return "bones";
  return k;
}

/**
 * Small, self-contained illustrative "scan" graphic for each organ — rendered
 * inside the detail popup so a person sees a recognizable picture of the
 * organ that was tapped, not just the label.
 */
function OrganIllustration({ organKey, color }: { organKey: string; color: string }) {
  const common = {
    fill: color,
    stroke: color,
  };

  let shapes: JSX.Element | null = null;

  switch (organKey) {
    case "brain":
      shapes = (
        <>
          <path
            d="M20 55 Q14 35 30 22 Q44 10 62 14 Q80 16 86 34 Q92 50 82 62 Q78 74 64 76 Q66 84 56 86 Q44 88 38 80 Q24 78 20 64 Q16 60 20 55 Z"
            fill={color}
            fillOpacity={0.85}
          />
          <g fill="none" stroke="#0b1220" strokeOpacity={0.35} strokeWidth={2} strokeLinecap="round">
            <path d="M30 30 Q40 26 46 34" />
            <path d="M48 22 Q56 30 54 40" />
            <path d="M62 26 Q72 32 70 44" />
            <path d="M28 50 Q38 46 44 54" />
            <path d="M40 62 Q50 58 58 64" />
          </g>
        </>
      );
      break;
    case "eyes":
      shapes = (
        <>
          <path d="M8 50 Q50 14 92 50 Q50 86 8 50 Z" fill={color} fillOpacity={0.25} stroke={color} strokeWidth={3} />
          <circle cx="50" cy="50" r="17" fill={color} />
          <circle cx="50" cy="50" r="7.5" fill="#0b1220" />
          <circle cx="45" cy="45" r="2.5" fill="#fff" fillOpacity={0.8} />
        </>
      );
      break;
    case "teeth":
      shapes = (
        <>
          <path
            d="M28 16 Q50 4 72 16 Q80 26 73 37 Q68 29 60 31 Q56 40 50 31 Q44 40 38 31 Q30 29 25 37 Q18 26 28 16 Z"
            fill={color}
          />
          <path d="M40 36 Q38 58 34 78 Q38 81 43 76 Q45 58 45 38 Z" fill={color} />
          <path d="M60 36 Q62 58 66 78 Q62 81 57 76 Q55 58 55 38 Z" fill={color} />
        </>
      );
      break;
    case "throat":
      shapes = (
        <>
          <path
            d="M37 8 Q33 8 33 14 L33 72 Q33 86 50 92 Q67 86 67 72 L67 14 Q67 8 63 8 Z"
            fill={color}
            fillOpacity={0.85}
          />
          <g stroke="#0b1220" strokeOpacity={0.35} strokeWidth={2}>
            <path d="M37 22 L63 22" />
            <path d="M36 34 L64 34" />
            <path d="M36 46 L64 46" />
            <path d="M37 58 L63 58" />
          </g>
        </>
      );
      break;
    case "heart":
      shapes = (
        <path
          d="M50 90 C18 64 6 42 6 26 C6 10 22 2 35 10 C42 14 47 20 50 27 C53 20 58 14 65 10 C78 2 94 10 94 26 C94 42 82 64 50 90 Z"
          fill={color}
        />
      );
      break;
    case "lungs":
      shapes = (
        <>
          <g stroke={color} strokeWidth={3} fill="none">
            <path d="M46 6 L46 26" />
            <path d="M54 6 L54 26" />
            <path d="M46 26 Q30 30 26 40" />
            <path d="M54 26 Q70 30 74 40" />
          </g>
          <path
            d="M26 40 Q10 46 8 66 Q6 86 22 90 Q34 92 36 78 Q38 60 36 44 Q34 38 26 40 Z"
            fill={color}
          />
          <path
            d="M74 40 Q90 46 92 66 Q94 86 78 90 Q66 92 64 78 Q62 60 64 44 Q66 38 74 40 Z"
            fill={color}
          />
        </>
      );
      break;
    case "liver":
      shapes = (
        <>
          <path
            d="M14 38 Q10 56 22 68 Q40 84 64 80 Q86 76 90 58 Q94 44 82 36 Q70 28 54 30 Q34 26 14 38 Z"
            fill={color}
          />
          <path d="M50 32 Q54 50 50 70" fill="none" stroke="#0b1220" strokeOpacity={0.3} strokeWidth={2} />
        </>
      );
      break;
    case "stomach":
      shapes = (
        <path
          d="M40 10 Q66 8 72 26 Q78 40 64 46 Q86 48 88 66 Q90 84 68 90 Q46 94 34 80 Q26 70 32 60 Q20 56 22 42 Q22 20 40 10 Z"
          fill={color}
        />
      );
      break;
    case "pancreas":
      shapes = (
        <path
          d="M12 50 Q12 38 26 36 Q50 32 76 42 Q90 48 88 56 Q86 64 70 62 Q44 60 24 62 Q12 62 12 50 Z"
          fill={color}
        />
      );
      break;
    case "kidneys":
      shapes = (
        <path
          d="M62 8 C40 8 24 26 24 50 C24 74 40 92 62 92 C70 92 70 84 62 80 C48 74 40 62 40 50 C40 38 48 26 62 20 C70 16 70 8 62 8 Z"
          fill={color}
        />
      );
      break;
    case "intestines":
      shapes = (
        <path
          d="M12 18 Q60 18 60 36 Q60 52 22 52 Q-6 52 4 72 Q12 88 52 88 Q82 88 88 64"
          fill="none"
          stroke={color}
          strokeWidth={11}
          strokeLinecap="round"
        />
      );
      break;
    case "skin":
      shapes = (
        <g fill={color}>
          <path d="M8 22 Q30 12 50 22 Q70 32 92 22 L92 32 Q70 42 50 32 Q30 22 8 32 Z" />
          <path d="M8 44 Q30 34 50 44 Q70 54 92 44 L92 54 Q70 64 50 54 Q30 44 8 54 Z" />
          <path d="M8 66 Q30 56 50 66 Q70 76 92 66 L92 76 Q70 86 50 76 Q30 66 8 76 Z" />
        </g>
      );
      break;
    case "bones":
      shapes = (
        <g fill={color}>
          <rect x="28" y="42" width="44" height="16" rx="8" />
          <circle cx="20" cy="42" r="11" />
          <circle cx="20" cy="58" r="11" />
          <circle cx="80" cy="42" r="11" />
          <circle cx="80" cy="58" r="11" />
        </g>
      );
      break;
    default:
      shapes = <circle cx="50" cy="50" r="30" fill={color} fillOpacity={0.5} />;
  }

  return (
    <svg
      viewBox="0 0 100 100"
      className="h-28 w-28"
      style={{ filter: `drop-shadow(0 0 14px ${color}aa)` }}
    >
      {shapes}
    </svg>
  );
}

export function BodyDamageMap({
  items,
  variant = "damage",
}: {
  items: BodyDamage[];
  variant?: BodyMapVariant;
}) {
  const mapped = items
    .map((it) => ({ ...it, key: normalizePart(it.part) }))
    .filter((it) => ORGANS[it.key]);
  const [active, setActive] = useState<number | null>(mapped.length ? 0 : null);
  const [detailOpen, setDetailOpen] = useState(false);

  const palette = SEVERITY_COLOR[variant];
  const stroke = BODY_STROKE[variant];
  const activeItem = active !== null ? mapped[active] : null;
  const activeOrgan = activeItem ? ORGANS[activeItem.key] : null;
  const sideLabel = variant === "benefit" ? "BENEFIT" : "RISK";
  const activeColor = activeItem ? palette[activeItem.severity] ?? palette.medium : stroke;

  const openOrgan = (idx: number) => {
    setActive(idx);
    setDetailOpen(true);
  };

  // Build a map of organKey → severity color for affected organs.
  const affectedColors = new Map<string, string>();
  mapped.forEach((it) => {
    affectedColors.set(it.key, palette[it.severity] ?? palette.medium);
  });

  return (
    <div className="grid gap-5 md:grid-cols-[1fr_1fr]">
      <div className="relative mx-auto w-full max-w-[340px]">
        <svg
          viewBox="0 0 260 600"
          className="h-auto w-full"
          style={{ filter: GLOW_SHADOW[variant] }}
        >
          {/* Body silhouette — standing reference-pose humanoid figure */}
          <g
            fill="rgba(125, 211, 252, 0.1)"
            stroke={stroke}
            strokeWidth="1.6"
            strokeLinejoin="round"
            strokeLinecap="round"
            opacity="0.9"
          >
            {/* Head */}
            <ellipse cx="134" cy="50" rx="30" ry="38" />
            <path d="M118 16 Q126 4 138 10 Q132 14 124 20 Z" />
            {/* Neck */}
            <path d="M122 86 L122 108 Q134 114 146 108 L146 86" />
            {/* Torso (shoulders → waist → hips, subtle crotch notch at the base) */}
            <path d="M88 116 Q72 124 70 144 L78 220 Q82 290 92 360 Q98 400 110 428 Q122 438 134 428 Q146 438 158 428 Q170 400 176 360 Q186 290 190 220 L198 144 Q196 124 180 116 Q158 108 134 108 Q110 108 88 116 Z" />
            {/* Left arm + open hand (viewer's left = subject's right arm), held slightly away from the torso */}
            <path d="M90 120 Q64 128 52 158 Q40 192 42 228 Q44 262 52 292 Q56 308 54 320 L40 322 Q32 324 30 332 Q29 339 34 344 Q39 349 45 345 Q48 351 52 345 Q57 350 61 344 Q66 348 69 342 Q67 335 62 330 Q66 322 60 318 Q57 308 63 296 Q70 264 70 228 Q70 192 84 158 Q92 138 96 122 Z" />
            {/* Right arm + open hand */}
            <path d="M178 120 Q204 128 216 158 Q228 192 226 228 Q224 262 216 292 Q212 308 214 320 L228 322 Q236 324 238 332 Q239 339 234 344 Q229 349 223 345 Q220 351 216 345 Q211 350 207 344 Q202 348 199 342 Q201 335 206 330 Q202 322 208 318 Q211 308 205 296 Q198 264 198 228 Q198 192 184 158 Q176 138 172 122 Z" />
            {/* Left leg + foot, stance slightly apart */}
            <path d="M100 430 Q90 478 88 516 Q86 548 84 566 Q82 578 90 586 Q98 592 110 590 Q122 588 122 576 Q122 560 120 540 Q118 488 124 430 Z" />
            {/* Right leg + foot */}
            <path d="M168 430 Q178 478 180 516 Q182 548 184 566 Q186 578 178 586 Q170 592 158 590 Q146 588 146 576 Q146 560 148 540 Q150 488 144 430 Z" />
          </g>

          {/* Subtle reference ribcage (always shown faintly) */}
          {affectedColors.has("bones") ? null : (
            <g
              fill="none"
              stroke={stroke}
              strokeOpacity="0.18"
              strokeWidth="0.8"
            >
              <path d="M104 158 L164 158 M104 170 L164 170 M104 182 L164 182 M104 194 L164 194" />
            </g>
          )}

          {/* All organs — faint outlines for the non-affected ones, vivid fill for affected */}
          {Object.entries(ORGANS).map(([key, organ]) => {
            const color = affectedColors.get(key);
            const isAffected = !!color;
            const isActive = activeItem?.key === key;
            return (
              <g
                key={key}
                onClick={() => {
                  const idx = mapped.findIndex((m) => m.key === key);
                  if (idx >= 0) openOrgan(idx);
                }}
                style={{ cursor: isAffected ? "pointer" : "default" }}
              >
                <path
                  d={organ.path}
                  fill={isAffected ? color : "transparent"}
                  fillOpacity={isAffected ? (isActive ? 0.85 : 0.55) : 0}
                  stroke={isAffected ? color : stroke}
                  strokeOpacity={isAffected ? 1 : 0.22}
                  strokeWidth={isAffected ? (isActive ? 2.2 : 1.6) : 0.9}
                  style={
                    isAffected
                      ? { filter: `drop-shadow(0 0 ${isActive ? 10 : 6}px ${color})` }
                      : undefined
                  }
                >
                  {isAffected && (
                    <animate
                      attributeName="fillOpacity"
                      values={`${isActive ? 0.85 : 0.55};${isActive ? 0.45 : 0.25};${isActive ? 0.85 : 0.55}`}
                      dur="2.2s"
                      repeatCount="indefinite"
                    />
                  )}
                </path>
              </g>
            );
          })}

          {/* Active callout */}
          {activeItem && activeOrgan && (
            <g>
              <line
                x1={activeOrgan.callout.x}
                y1={activeOrgan.callout.y}
                x2={activeOrgan.anchor.x}
                y2={activeOrgan.anchor.y}
                stroke={palette[activeItem.severity]}
                strokeWidth="1.2"
                strokeDasharray="3 3"
                opacity="0.9"
              />
              <circle
                cx={activeOrgan.callout.x}
                cy={activeOrgan.callout.y}
                r="3"
                fill={palette[activeItem.severity]}
              />
              <g
                transform={`translate(${activeOrgan.callout.x < 130 ? activeOrgan.callout.x - 4 : activeOrgan.callout.x + 4}, ${activeOrgan.callout.y})`}
                textAnchor={activeOrgan.callout.x < 130 ? "end" : "start"}
              >
                <text
                  y="-3"
                  fill={palette[activeItem.severity]}
                  fontSize="12"
                  fontWeight="700"
                  style={{ filter: `drop-shadow(0 0 4px ${palette[activeItem.severity]})` }}
                >
                  {activeOrgan.label}
                </text>
                <text y="10" fill="#cbd5e1" fontSize="9" fontWeight="500">
                  {activeItem.severity.toUpperCase()} {sideLabel}
                </text>
              </g>
            </g>
          )}
        </svg>
      </div>

      <div>
        <p className="mb-3 text-xs uppercase tracking-wider text-muted-foreground">
          Tap an organ · {mapped.length} {variant === "benefit" ? "benefiting" : "affected"} area{mapped.length === 1 ? "" : "s"}
        </p>
        <ul className="space-y-2">
          {mapped.map((it, i) => {
            const organ = ORGANS[it.key];
            const color = palette[it.severity] ?? palette.medium;
            const isActive = active === i;
            return (
              <li
                key={i}
                onClick={() => openOrgan(i)}
                className={`cursor-pointer rounded-lg border p-3 text-sm transition-all ${
                  isActive
                    ? "border-primary bg-muted ring-2 ring-primary/30"
                    : "border-border bg-card hover:border-primary/50"
                }`}
              >
                <div className="flex items-center gap-2">
                  <span
                    className="inline-block h-2.5 w-2.5 rounded-full"
                    style={{ background: color, boxShadow: `0 0 6px ${color}` }}
                  />
                  <span className="font-semibold">{organ.label}</span>
                  <span className="ml-auto text-[10px] uppercase tracking-wider text-muted-foreground">
                    {it.severity}
                  </span>
                </div>
                {it.trigger && (
                  <div className="mt-1.5">
                    <span
                      className="inline-block rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider"
                      style={{ color, borderColor: color, background: `${color}14` }}
                    >
                      {variant === "benefit" ? "From " : "Caused by "}{it.trigger}
                    </span>
                  </div>
                )}
                <p className="mt-1 text-muted-foreground">{it.reason}</p>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Organ detail popup — shown when an affected organ is tapped */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-sm">
          {activeItem && activeOrgan && (
            <>
              <DialogHeader>
                <DialogTitle className="flex flex-col items-center gap-3 text-center">
                  <div
                    className="flex h-32 w-32 items-center justify-center rounded-full"
                    style={{
                      background: `radial-gradient(circle, ${activeColor}22, transparent 70%)`,
                    }}
                  >
                    <OrganIllustration organKey={activeItem.key} color={activeColor} />
                  </div>
                  <span className="font-display text-xl">{activeOrgan.label}</span>
                  <span
                    className="inline-block rounded-full border px-3 py-1 text-[11px] font-semibold uppercase tracking-wider"
                    style={{ color: activeColor, borderColor: activeColor, background: `${activeColor}14` }}
                  >
                    {activeItem.severity.toUpperCase()} {sideLabel}
                  </span>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-3 text-left">
                {activeItem.trigger && (
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                      {variant === "benefit" ? "From" : "Caused by"}
                    </p>
                    <p className="text-sm font-semibold" style={{ color: activeColor }}>
                      {activeItem.trigger}
                    </p>
                  </div>
                )}
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    What's happening
                  </p>
                  <p className="text-sm text-foreground">{activeItem.reason}</p>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
